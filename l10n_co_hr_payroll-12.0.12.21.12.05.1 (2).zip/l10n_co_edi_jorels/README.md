l10n_co_edi_jorels
------------------

Copyright (2019-2021) - Jorels SAS

[info@jorels.com](mailto:info@jorels.com)

[https://www.jorels.com](https://www.jorels.com)

Under LGPL (Lesser General Public License)

### Odoo module for electronic invoicing for Colombia

Tested on Odoo Community version 12
