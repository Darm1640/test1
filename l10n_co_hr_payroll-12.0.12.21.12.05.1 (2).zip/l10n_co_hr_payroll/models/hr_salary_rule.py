# -*- coding: utf-8 -*-
#
#   l10n_co_hr_payroll
#   Copyright (C) 2021  Jorels SAS
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU Affero General Public License as published
#   by the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU Affero General Public License for more details.
#
#   You should have received a copy of the GNU Affero General Public License
#   along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
#   email: info@jorels.com
#


from odoo import fields, models, api


class HrSalaryRule(models.Model):
    _inherit = 'hr.salary.rule'

    type_concept = fields.Selection([
        ('earn', 'Earn'),
        ('deduction', 'Deduction'),
        ('other', 'Other')
    ], string="Type concept", default="other", required=True)

    earn_category = fields.Selection([
        ('basic', 'Basic'),
        ('vacation_common', 'Vacation common'),
        ('vacation_compensated', 'Vacation compensated'),
        ('primas', 'Primas'),
        ('primas_non_salary', 'Primas non salary'),
        ('layoffs', 'Layoffs'),
        ('layoffs_interest', 'Layoffs interest'),
        ('licensings_maternity_or_paternity_leaves', 'Licensings maternity or paternity leaves'),
        ('licensings_permit_or_paid_licenses', 'Licensings permit or paid licenses'),
        ('licensings_suspension_or_unpaid_leaves', 'Licensings suspension or unpaid leaves'),
        ('endowment', 'Endowment'),
        ('sustainment_support', 'Sustainment support'),
        ('telecommuting', 'Telecommuting'),
        ('company_withdrawal_bonus', 'Company withdrawal bonus'),
        ('compensation', 'Compensation'),
        ('refund', 'Refund'),
        ('transports_assistance', 'Transports assistance'),
        ('transports_viatic', 'Transports viatic'),
        ('transports_non_salary_viatic', 'Transports non salary viatic'),
        ('daily_overtime', 'Daily overtime'),
        ('overtime_night_hours', 'Overtime night hours'),
        ('hours_night_surcharge', 'Hours night surcharge'),
        ('sunday_holiday_daily_overtime', 'Sunday and Holiday daily overtime'),
        ('daily_surcharge_hours_sundays_holidays', 'Daily surcharge hours on sundays and holidays'),
        ('sunday_night_overtime_holidays', 'Sunday night overtime and holidays'),
        ('sunday_holidays_night_surcharge_hours', 'Sunday and holidays night surcharge hours'),
        ('incapacities_common', 'Incapacities common'),
        ('incapacities_professional', 'Incapacities professional'),
        ('incapacities_working', 'Incapacities working'),
        ('bonuses', 'Bonuses'),
        ('bonuses_non_salary', 'Non salary bonuses'),
        ('assistances', 'Assistances'),
        ('assistances_non_salary', 'Non salary assistances'),
        ('legal_strikes', 'Legal strikes'),
        ('other_concepts', 'Other concepts'),
        ('other_concepts_non_salary', 'Non salary other concepts'),
        ('compensations_ordinary', 'Compensations ordinary'),
        ('compensations_extraordinary', 'Compensations extraordinary'),
        ('vouchers', 'Vouchers'),
        ('vouchers_non_salary', 'Vouchers non salary'),
        ('vouchers_salary_food', 'Vouchers salary food'),
        ('vouchers_non_salary_food', 'Vouchers non salary food'),
        ('commissions', 'Commissions'),
        ('third_party_payments', 'Third party payments'),
        ('advances', 'Advances')
    ], string="Earn category", default="other_concepts", required=True)

    deduction_category = fields.Selection([
        ('health', 'Health'),
        ('pension_fund', 'Pension fund'),
        ('pension_security_fund', 'Pension security fund'),
        ('pension_security_fund_subsistence', 'Pension security fund subsistence'),
        ('voluntary_pension', 'Voluntary pension'),
        ('withholding_source', 'Withholding source'),
        ('afc', 'Afc'),
        ('cooperative', 'Cooperative'),
        ('tax_lien', 'Tax lien'),
        ('complementary_plans', 'Complementary plans'),
        ('education', 'Education'),
        ('refund', 'Refund'),
        ('debt', 'Debt'),
        ('trade_unions', 'Trade unions'),
        ('sanctions_public', 'Sanctions public'),
        ('sanctions_private', 'Sanctions private'),
        ('libranzas', 'Libranzas'),
        ('third_party_payments', 'Third party payments'),
        ('advances', 'Advances'),
        ('other_deductions', 'Other deductions')
    ], string="Deduction category", default="other_deductions", required=True)
