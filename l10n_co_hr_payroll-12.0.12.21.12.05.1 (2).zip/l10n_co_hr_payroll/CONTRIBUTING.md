Jorels SAS
----------

Desarrollo
==========
Jorge Sanabria, desarrollo del código fuente del modulo

Aportes de conocimiento
=======================
David Alejandro De La Rosa Maldonado, asesoró el desarrollo con sus grandes conocimientos en el tema de nómina de Odoo
